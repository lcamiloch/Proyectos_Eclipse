package co.com.googlepom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SerarchGooglePOM {
	
	private WebDriver controlador;
	
			
			
// Bajar java de Julian
			
}
	